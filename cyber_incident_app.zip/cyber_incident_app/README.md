# Cyber Incident Relationship & Timeline Database — Web App

A small Flask app on top of the `CyberIncidentDB` SQL Server database.

## 1. Database
Run `create_cyber_incident_db.sql` in SSMS first (from the earlier step) so the
`CyberIncidentDB` database and its tables exist.

## 2. Install dependencies
```
pip install -r requirements.txt
```
You also need the **ODBC Driver 17 for SQL Server** installed on your machine
(Microsoft's free download — search "ODBC Driver 17 for SQL Server download").

## 3. Configure the connection
Open `app.py` and update:
```python
SERVER_NAME = "localhost\\SQLEXPRESS"
```
Change this to match your actual SQL Server instance name. If you installed
plain SQL Server Developer Edition (not Express), it's often just `"localhost"`.

## 4. Run the app
```
python app.py
```
Then open `http://127.0.0.1:5000` in your browser.

## Features
- Dashboard listing all incidents with severity/status
- Incident detail page: timeline, linked threat actors, affected assets
- Form to create a new incident
- Form to log a new timeline event (auto-marks incident "Resolved" if you log a Resolved event)

## Folder structure
```
cyber_incident_app/
  app.py
  requirements.txt
  templates/
    base.html
    index.html
    incident_detail.html
    add_incident.html
    add_event.html
```
