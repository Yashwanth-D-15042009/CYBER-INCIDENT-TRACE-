"""
Cyber Incident Relationship & Timeline Database - Flask Backend
Connects to SQL Server (CyberIncidentDB) via pyodbc.
"""

from flask import Flask, render_template, request, redirect, url_for, flash
import pyodbc

app = Flask(__name__)
app.secret_key = "change-this-secret-key"  # needed for flash messages

# ---------------------------------------------------------
# DATABASE CONNECTION
# Update SERVER_NAME to match your SQL Server instance name.
# Examples: "localhost", "localhost\\SQLEXPRESS", "DESKTOP-ABC\\SQLEXPRESS"
# ---------------------------------------------------------
SERVER_NAME = "localhost\\SQLEXPRESS"
DATABASE_NAME = "CyberIncidentDB"

CONN_STR = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={SERVER_NAME};"
    f"DATABASE={DATABASE_NAME};"
    f"Trusted_Connection=yes;"  # uses Windows Authentication
)


def get_db_connection():
    return pyodbc.connect(CONN_STR)


# ---------------------------------------------------------
# ROUTES
# ---------------------------------------------------------

@app.route("/")
def dashboard():
    """List all incidents with org name, severity, status."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT I.IncidentID, I.Title, I.IncidentType, I.Severity,
               I.Status, I.DateReported, O.Name AS OrgName
        FROM Incidents I
        JOIN Organizations O ON I.OrgID = O.OrgID
        ORDER BY I.DateReported DESC
    """)
    incidents = cursor.fetchall()
    conn.close()
    return render_template("index.html", incidents=incidents)


@app.route("/incident/<int:incident_id>")
def incident_detail(incident_id):
    """Show one incident: details, timeline, linked actors, linked assets."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT I.IncidentID, I.Title, I.IncidentType, I.Severity,
               I.Status, I.DateReported, O.Name AS OrgName, O.Sector
        FROM Incidents I
        JOIN Organizations O ON I.OrgID = O.OrgID
        WHERE I.IncidentID = ?
    """, incident_id)
    incident = cursor.fetchone()

    cursor.execute("""
        SELECT EventTime, EventType, Description
        FROM TimelineEvents
        WHERE IncidentID = ?
        ORDER BY EventTime ASC
    """, incident_id)
    timeline = cursor.fetchall()

    cursor.execute("""
        SELECT TA.Name, TA.Alias, IA.RoleInAttack
        FROM IncidentActors IA
        JOIN ThreatActors TA ON IA.ActorID = TA.ActorID
        WHERE IA.IncidentID = ?
    """, incident_id)
    actors = cursor.fetchall()

    cursor.execute("""
        SELECT A.Name, A.AssetType, IAs.ImpactLevel
        FROM IncidentAssets IAs
        JOIN Assets A ON IAs.AssetID = A.AssetID
        WHERE IAs.IncidentID = ?
    """, incident_id)
    assets = cursor.fetchall()

    conn.close()
    return render_template(
        "incident_detail.html",
        incident=incident, timeline=timeline, actors=actors, assets=assets
    )


@app.route("/incident/new", methods=["GET", "POST"])
def add_incident():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        org_id = request.form["org_id"]
        title = request.form["title"]
        incident_type = request.form["incident_type"]
        severity = request.form["severity"]

        cursor.execute("""
            INSERT INTO Incidents (OrgID, Title, IncidentType, Severity, Status)
            VALUES (?, ?, ?, ?, 'Open')
        """, org_id, title, incident_type, severity)
        conn.commit()
        conn.close()
        flash("Incident created successfully.")
        return redirect(url_for("dashboard"))

    cursor.execute("SELECT OrgID, Name FROM Organizations ORDER BY Name")
    organizations = cursor.fetchall()
    conn.close()
    return render_template("add_incident.html", organizations=organizations)


@app.route("/incident/<int:incident_id>/add_event", methods=["GET", "POST"])
def add_event(incident_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        event_time = request.form["event_time"]
        event_type = request.form["event_type"]
        description = request.form["description"]

        cursor.execute("""
            INSERT INTO TimelineEvents (IncidentID, EventTime, EventType, Description)
            VALUES (?, ?, ?, ?)
        """, incident_id, event_time, event_type, description)

        # Optional: auto-update incident status when a "Resolved" event is logged
        if event_type == "Resolved":
            cursor.execute("""
                UPDATE Incidents SET Status = 'Resolved' WHERE IncidentID = ?
            """, incident_id)

        conn.commit()
        conn.close()
        flash("Timeline event added.")
        return redirect(url_for("incident_detail", incident_id=incident_id))

    conn.close()
    return render_template("add_event.html", incident_id=incident_id)


if __name__ == "__main__":
    app.run(debug=True)
